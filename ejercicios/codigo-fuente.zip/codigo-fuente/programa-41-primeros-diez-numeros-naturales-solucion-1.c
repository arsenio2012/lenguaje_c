/* Programa: Primeros diez n�meros naturales (Soluci�n 1) */

#include <conio.h>
#include <stdio.h>

int main()
{
	printf( "\n   1 2 3 4 5 6 7 8 9 10" );

	getch(); /* Pausa */

	return 0;
}
