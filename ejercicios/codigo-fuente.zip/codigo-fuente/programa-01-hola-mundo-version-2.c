/* Programa: Hola mundo (Versi�n 2) */

#include <conio.h>
#include <stdio.h>

int main()
{
	printf( "\n   Hola mundo." );
	printf( "\n\n   Pulse una tecla para salir..." );

	getch(); /* Pausa */

	return 0;
}

